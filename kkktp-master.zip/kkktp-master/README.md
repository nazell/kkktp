## KK & KTP Generator
# Command Install For Termux / Linux (pc)
```
$ pkg install php
$ pkg install git
$ git clone https://github.com/IndonesianSecurity/kkktp
$ cd kkktp
$ ls
$ php kkktp.php
```
# Autor
Greyanonymous  

# Spesial Thank
Indonesian Security || Indoxploit
