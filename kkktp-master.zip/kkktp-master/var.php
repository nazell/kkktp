<?php
$white = "\e[97m";
$black = "\e[30m\e[1m";
$yellow = "\e[93m";
$orange = "\e[38;5;208m";
$blue   = "\e[34m";
$lblue  = "\e[36m";
$cln    = "\e[0m";
$green  = "\e[92m";
$fgreen = "\e[32m";
$red    = "\e[91m";
$magenta = "\e[35m";
$bluebg = "\e[44m";
$lbluebg = "\e[106m";
$greenbg = "\e[42m";
$lgreenbg = "\e[102m";
$yellowbg = "\e[43m";
$lyellowbg = "\e[103m";
$redbg = "\e[101m";
$grey = "\e[37m";
$cyan = "\e[36m";
$bold   = "\e[1m";
function kkktp_banner(){
  echo "\e[91;1m
       					  ls
					 dNd
					'kNl
.lK0	      cKK			0No		    dXk		     dNKdoolc   oOd:'
'OWWd   lXXo  kMWx   cKXo		dNWXo		    KMXc   dNKc	   :xXMMMMMMWK  0MWWKx;
,0WWx   kWWd  OMWx   xWWd	       kNMMNo		    KMNl   0WXc  d0NMMMMWXKNWK  0MMMMWXx'
,OMWx   KMX   OMWk   KMXc	      OWMN0l		    KMNl  lNW0, OMMMMMMWO       0MNkoOWWk'
'OMWx  xWWk   kWMk  dWWO	     xWWO		    KMNl  OWWo  lXN0OXMWd	kMNl  dNNo
'kMWk  XMNo   kMMk  KMWd	     KM0		    KMNo.oNMX:       OMWo	kMWo  ;KWO,
'kMMk kWMK    xWMk xWMX		    dWMK		    0MNo:0WWO'       kWWd	xWWx  oNM0;
.xWWxoXMWd    xWMkoKMWx		    xWMMXkxkc		    0MNoxWMXc	     xWWx	oNWOlxNMMk'
.xWWOOWMK     dWWOOWMK		    cXMMMMMWd		    OMNk0MWO'	     dWMk	lNMWWMMMXc
.dWWNNMMO     oWMNNMMO		     lXMMMWK		    OMWNWMWd	     oNMO	:XMMMMMXl
.dWMMMMNl     oWMMMMNo		     cXWXOo		    kMMMMMK:	     lNMO	;KMMNKx;
.dWMMMWk      oWMMMWO		     0W0		    kMMMMNd	     cXMO	,0MNo'
.dWMMMXl      oWMMMNl		    lNNo		    kMMMMK;	     cXMO	,OMXc
.dWMMMWKxc    oWMMMWKxc		    lNWk      od	    kWMMMW0d:	     :XMO	,OMXc
.oWMMMMMMW0o  lNMMMMMMWKo	    cXMWKkxx0NWK	    kWMMMMMMNOc      :XMO	,OMNl
.lNMN0KWMMWWk cXMNKKWMMMWk	     KMMMMMMWWXl	    xWMX0XWMMWNo     cXMk	,OMNo
.cNMK  ckXMMNc XMXc'cxXWMNl	     oNMMMWXOo		    dWWk  lONWM0     lNWx	'kMNl
.cNMX     x0x, KMXc     x0x	      cXWkc		    oWWO    ;k0o      OXl	 c00;
.:XMXc	       KMNl		       KK		    oWM0;             ';          ''
.;0MK	       0MXc		      cXk		    lNWO,
..cxc	       cxl		      oXo		     ox;
                                       o'
 
  \n";
}
?>
